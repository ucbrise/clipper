Clipper
========

Library for creating and managing a Clipper model serving Cluster.

To learn more about Clipper visit our website <http://clipper.ai> or check us out on GitHub <https://github.com/ucbrise/clipper>.

You can contact us at <clipper-dev@googlegroups.com>
